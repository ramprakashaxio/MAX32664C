#include "mbed.h"
#include <chrono>
using namespace std::chrono;

// I2C addresses for MAX32664C sensor hub (7-bit address 0x55 -> 8-bit write: 0xAA, read: 0xAB)
#define HUB_I2C_WRITE_ADDR 0xAA
#define HUB_I2C_READ_ADDR  0xAB

#ifndef I2C_SDA
  #define I2C_SDA I2C_SDA0
#endif

#ifndef I2C_SCL
  #define I2C_SCL I2C_SCL0
#endif

// Pin assignments (nRF52832 DK example: P0.05 = RESET, P0.06 = MFIO)
// Adjust these according to your wiring.
DigitalOut reset_pin(P0_5);
DigitalOut mfio_pin(P0_6);

// Use the default SDA/SCL defined for your board
I2C i2c(I2C_SDA, I2C_SCL);  // Mbed uses 7-bit addresses internally

// Helper functions to control MFIO (wake/sleep)
// MFIO must be pulled low at least 250-300 us before starting an I2C transaction and kept low during the transaction.
inline void hub_wake() {
    mfio_pin = 0;
    printf(">> hub_wake: MFIO set LOW\n");
    wait_us(300);  // Wait 300 us to ensure hub wakes up
}
inline void hub_sleep() {
    mfio_pin = 1;
    printf(">> hub_sleep: MFIO set HIGH\n");
}

int main() {
    // Start-up debug message
    printf("\n*** Starting MAX32664C initialization ***\r\n");

    // 1. Reset into Application mode
    printf("\n[Step 1] Resetting sensor hub into Application Mode...\r\n");
    // Ensure MFIO is high (to select Application mode)
    mfio_pin = 1;
    printf("   [Reset] MFIO set HIGH\n");
    // Drive RESET low for at least 10 ms
    reset_pin = 0;
    printf("   [Reset] RESET pin set LOW\n");
    ThisThread::sleep_for(10ms);
    // Keep MFIO high during RESET low; then release RESET
    reset_pin = 1;
    printf("   [Reset] RESET pin released (set HIGH)\n");
    // Wait 50 ms for bootup, then wait ~1.5 s for full application initialization
    ThisThread::sleep_for(50ms);
    ThisThread::sleep_for(1500ms);
    printf("   [Reset] Reset complete. Device should now be in Application Mode.\r\n");

    // 2. Read hub operating mode to verify it is in Application mode
    // Command: {0x02, 0x00} -> Expect response: status 0x00 and mode 0x00 (Application)
    printf("\n[Step 2] Reading hub operating mode...\r\n");
    uint8_t cmd_mode[2] = {0x02, 0x00};  // Family 0x02, Index 0x00
    uint8_t mode_resp[2] = {0};
    hub_wake();
    int ret = i2c.write(HUB_I2C_WRITE_ADDR, (char*)cmd_mode, 2, true);
    printf("   [Mode] Write returned: %d\r\n", ret);
    ret = i2c.read(HUB_I2C_READ_ADDR, (char*)mode_resp, 2);
    printf("   [Mode] Read returned: %d, Bytes: 0x%02X 0x%02X\r\n", ret, mode_resp[0], mode_resp[1]);
    hub_sleep();
    if (ret != 0 || mode_resp[0] != 0x00) {
        printf("!!! Error: Operating mode read failed (status 0x%02X). Ensure the hub is in Application Mode.\r\n", mode_resp[0]);
    } else {
        printf("   [Mode] Operating mode = 0x%02X (0x00 indicates Application Mode)\r\n", mode_resp[1]);
    }

    // 3. Enable AFE (MAX86141) via sensor hub
    printf("\n[Step 3] Enabling MAX86141 AFE...\r\n");
    uint8_t cmd_enable_AFE[4] = {0x44, 0x00, 0x01, 0x00};  // Family 0x44, Index 0x00, Data 0x0100
    char status;
    hub_wake();
    ret = i2c.write(HUB_I2C_WRITE_ADDR, (char*)cmd_enable_AFE, 4, false);
    printf("   [AFE] Write returned: %d\r\n", ret);
    ThisThread::sleep_for(5ms);  // Small delay to allow hub to configure AFE
    ret = i2c.read(HUB_I2C_READ_ADDR, &status, 1);
    printf("   [AFE] Read returned: %d, Status: 0x%02X\r\n", ret, status);
    hub_sleep();
    if (ret != 0 || status != 0x00) {
        printf("!!! Error: Enable AFE failed (status 0x%02X). Check wiring and timing.\r\n", status);
        while (true) { } // Halt on error
    }
    printf("   [AFE] MAX86141 AFE enabled (status 0x%02X).\r\n", status);

    // 4. Enable accelerometer (KX122) via sensor hub
    printf("\n[Step 4] Enabling KX122 accelerometer...\r\n");
    uint8_t cmd_enable_accel[4] = {0x44, 0x04, 0x01, 0x00};  // Family 0x44, Index 0x04, Data 0x0100
    hub_wake();
    ret = i2c.write(HUB_I2C_WRITE_ADDR, (char*)cmd_enable_accel, 4, false);
    printf("   [Accel] Write returned: %d\r\n", ret);
    ThisThread::sleep_for(20ms);  // Wait 20 ms per documentation
    ret = i2c.read(HUB_I2C_READ_ADDR, &status, 1);
    printf("   [Accel] Read returned: %d, Status: 0x%02X\r\n", ret, status);
    hub_sleep();
    if (ret != 0 || status != 0x00) {
        printf("!!! Error: Enable accelerometer failed (status 0x%02X). Check wiring and delays.\r\n", status);
        while (true) { } // Halt on error
    }
    printf("   [Accel] KX122 accelerometer enabled (status 0x%02X).\r\n", status);

    // 5. Activate WHRM (HR + SpO2) algorithm in normal mode
    printf("\n[Step 5] Activating WHRM algorithm (HR + SpO2) in normal mode...\r\n");
    uint8_t cmd_start_algo[3] = {0x52, 0x07, 0x01};  // Family 0x52, Index 0x07, Data 0x01
    hub_wake();
    ret = i2c.write(HUB_I2C_WRITE_ADDR, (char*)cmd_start_algo, 3, false);
    printf("   [Algo] Write returned: %d\r\n", ret);
    ThisThread::sleep_for(500ms);  // Wait ~465 ms for algorithm initialization
    ret = i2c.read(HUB_I2C_READ_ADDR, &status, 1);
    printf("   [Algo] Read returned: %d, Status: 0x%02X\r\n", ret, status);
    hub_sleep();
    if (ret != 0 || status != 0x00) {
        printf("!!! Error: Algorithm start failed (status 0x%02X). Verify command sequence and delays.\r\n", status);
        while (true) { } // Halt on error
    }
    printf("   [Algo] WHRM algorithm started (status 0x%02X). Now collecting data...\r\n", status);

    // 6. Continuous reading of FIFO for algorithm results
    printf("\n[Step 6] Starting continuous FIFO polling for algorithm results...\r\n");
    const int SAMPLE_SIZE = 48;  // bytes per sample (PPG: 18 + Accel: 6 + Algo: 24)
    static uint8_t fifo_data[300];  // Buffer for FIFO data
    while (true) {
        // 6a. Poll hub status to check if new data is ready (DataRdyInt bit = bit3)
        uint8_t cmd_get_status[2] = {0x00, 0x00};
        uint8_t status_byte = 0;
        hub_wake();
        ret = i2c.write(HUB_I2C_WRITE_ADDR, (char*)cmd_get_status, 2, false);
        printf("   [FIFO] Status write returned: %d\r\n", ret);
        ret = i2c.read(HUB_I2C_READ_ADDR, (char*)&status_byte, 1);
        printf("   [FIFO] Status read returned: %d, Status byte: 0x%02X\r\n", ret, status_byte);
        hub_sleep();
        bool data_ready = status_byte & 0x08;  // Check DataRdyInt (bit3)
        if (!data_ready) {
            printf("   [FIFO] Data not ready (Status byte: 0x%02X). Polling again...\r\n", status_byte);
            ThisThread::sleep_for(5ms);
            continue;
        }

        // 6b. Read number of samples in FIFO (command: {0x12, 0x00})
        uint8_t cmd_count[2] = {0x12, 0x00};
        uint8_t count_resp[2] = {0};
        hub_wake();
        ret = i2c.write(HUB_I2C_WRITE_ADDR, (char*)cmd_count, 2, true);
        printf("   [FIFO] Count write returned: %d\r\n", ret);
        ret = i2c.read(HUB_I2C_READ_ADDR, (char*)count_resp, 2);
        printf("   [FIFO] Count read returned: %d, Response: 0x%02X 0x%02X\r\n", ret, count_resp[0], count_resp[1]);
        hub_sleep();
        if (count_resp[0] != 0x00) {
            printf("!!! [FIFO] Error: FIFO count read failed (status 0x%02X)\r\n", count_resp[0]);
            while (true) { } // Halt on error
        }
        uint8_t num_samples = count_resp[1];
        if (num_samples == 0) {
            printf("   [FIFO] Warning: No samples available despite data ready.\r\n");
            continue;
        }

        // 6c. Read FIFO data (command: {0x12, 0x01})
        uint8_t cmd_read_fifo[2] = {0x12, 0x01};
        int bytes_to_read = 1 + num_samples * SAMPLE_SIZE;  // 1 status byte + sample data
        if (bytes_to_read > sizeof(fifo_data)) {
            bytes_to_read = sizeof(fifo_data);  // Limit to buffer size
        }
        hub_wake();
        ret = i2c.write(HUB_I2C_WRITE_ADDR, (char*)cmd_read_fifo, 2, true);
        printf("   [FIFO] FIFO data write returned: %d\r\n", ret);
        ret = i2c.read(HUB_I2C_READ_ADDR, (char*)fifo_data, bytes_to_read);
        printf("   [FIFO] FIFO data read returned: %d, First byte (status): 0x%02X\r\n", ret, fifo_data[0]);
        hub_sleep();
        if (ret != 0 || fifo_data[0] != 0x00) {
            printf("!!! [FIFO] Error: FIFO data read failed (status 0x%02X)\r\n", fifo_data[0]);
            while (true) { } // Halt on error
        }

        // 6d. Parse and print each sample in the FIFO
        int offset = 1;  // Skip the first status byte
        for (uint8_t sample = 0; sample < num_samples; ++sample) {
            const uint8_t *data = fifo_data + offset;
            // For normal algorithm mode, algorithm data is at offset 24 within each sample
            const uint8_t *algo = data + 24;
            uint16_t hr = (algo[1] << 8) | algo[2];        // Heart rate (scaled by 10)
            uint8_t hr_conf = algo[3];                     // HR confidence (%)
            uint16_t rr = (algo[4] << 8) | algo[5];          // RR interval (scaled by 10)
            uint8_t rr_conf = algo[6];                     // RR confidence (%)
            uint8_t activity = algo[7];                    // Activity class
            uint16_t r_value = (algo[8] << 8) | algo[9];     // SpO2 R value (scaled by 1000)
            uint8_t spo2_conf = algo[10];                  // SpO2 confidence (%)
            uint16_t spo2 = (algo[11] << 8) | algo[12];      // SpO2 (scaled by 10)
            uint8_t spo2_complete = algo[13];              // SpO2 completion (%)
            uint8_t low_quality = algo[14];                // Low quality flag
            uint8_t motion_flag = algo[15];                // Motion flag
            uint8_t low_pi_flag = algo[16];                // Low perfusion index flag
            uint8_t unreliable_r = algo[17];               // R value unreliable flag
            uint8_t spo2_state = algo[18];                 // SpO2 algorithm state
            uint8_t scd_state = algo[19];                  // Skin contact state

            // Convert scaled values to human-readable form
            float hr_val = hr / 10.0f;         // Convert HR to bpm
            float spo2_val = spo2 / 10.0f;     // Convert SpO2 to percentage

            const char* scd_str;
            switch (scd_state) {
                case 3: scd_str = "On skin"; break;
                case 2: scd_str = "Near skin"; break;
                case 1: scd_str = "Off skin"; break;
                default: scd_str = "Undetected"; break;
            }

            printf("Sample %d: HR = %.1f bpm (Conf %d%%), SpO2 = %.1f%% (Conf %d%%), SCD: %s\r\n",
                   sample + 1, hr_val, hr_conf, spo2_val, spo2_conf, scd_str);
            offset += SAMPLE_SIZE;
        }
        // Delay before polling again (approx. 25 Hz sampling rate)
        ThisThread::sleep_for(40ms);
    }
}
